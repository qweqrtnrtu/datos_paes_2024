require('tidyverse')

setwd('DIRECCION AL DIRECTORIO CON ARCHIVOS')

########### ARMADO DE LOS DATOS ##############

jsonlite::read_json('puntajesCompletos.json') %>% 
tidyjson::as.tbl_json(.) %>%
tidyjson::spread_all(.) %>% 
as_tibble(.) %>%
filter(`lectura.cantidad` > 4 & `matemática1.cantidad` > 4 & `promedio.cantidad` > 4 & 
`nem.cantidad` > 4 & `ranking.cantidad` > 4) %>%
rename("matemática1"= "matemática1.promedio", "matemática2" = "matemática2.promedio",
lectura = lectura.promedio, ciencias = ciencias.promedio, 
  historia = historia.promedio, nem = nem.promedio, ranking = ranking.promedio) -> datos

read_delim(
    "20230912_Directorio_Oficial_EE_2023_20230430_WEB.csv",
    delim = ";",
    name_repair = "universal") %>%
select(RBD, COD_DEPE, NOM_COM_RBD, COD_REG_RBD) %>%
rename(dep=COD_DEPE) -> directorio

left_join(
    datos,
    directorio,
    by = join_by(rbd == RBD)) -> datos

read_delim("simce2m2022_rbd_final.csv", delim="|") %>%
select(rbd, cod_grupo) %>%
rename(nseId = cod_grupo) -> simce

left_join(
    datos,
    simce,
    by = join_by(rbd == rbd)) -> datos

jsonlite::read_json('nombres_corregidos.json') %>% 
tidyjson::as.tbl_json(.) %>%
tidyjson::spread_all(.) %>% 
as_tibble(.) %>%
select(-document.id) %>%
mutate(rbd = as.double(rbd)) -> nombres

left_join(
    datos,
    nombres,
    by = join_by(rbd == rbd)) -> datos

datos %>%
group_by(NOM_COM_RBD) %>%
mutate(nseComunaId = round(mean(nseId, na.rm=TRUE))) %>%
ungroup() %>%
mutate(
    nseId = case_when(
        !is.na(nseId) ~ nseId,
        is.na(nseId) ~ nseComunaId
        ),
    nse = recode_factor(
        nseId,
        `1` = "Bajo",
        `2` = "Medio Bajo",
        `3` = "Medio",
        `4` = "Medio Alto",
        `5` = "Alto"
    ),
    dep = plyr::mapvalues(
        dep,
        from = c(1,2,3,4,5,6),
        to = c(1,1,2,3,1,1)
    ) %>% 
        recode_factor(
            `1` = "Público",
            `2` = "P. C/Subv",
            `3` = "P. S/Subv"
        ),
    comuna = stringr::str_to_title(NOM_COM_RBD),
    `región` = plyr::mapvalues(
        COD_REG_RBD,
        from=1:16,
        to=c("TA", "AN", "AT", "CO", "VA", "LI", "ML", "BI", "AR", "LL", "AI", "MA", "RM", "LR", "AP", "NB")
    ),
    promedio = (`matemática1`*`matemática1.cantidad` + 
      `matemática2`*`matemática2.cantidad` +
      `lectura`*`lectura.cantidad` +
      `ciencias`*`ciencias.cantidad` + 
      `historia`*`historia.cantidad` + 
      `nem`*`nem.cantidad` +
      `ranking`*`ranking.cantidad`) /
      (`matemática1.cantidad` + `matemática2.cantidad` +
         `lectura.cantidad` + `ciencias.cantidad` + 
         `historia.cantidad` + `nem.cantidad` +
         `ranking.cantidad`),
    posPromedio = rank(-promedio, ties.method="min"),
    posMatemática1 = rank(-matemática1, ties.method="min"),
    posMatemática2 = rank(-matemática2, ties.method="min"),
    posLectura = rank(-lectura, ties.method="min"),
    posCiencias = rank(-ciencias, ties.method="min"),
    posHistoria = rank(-historia, ties.method="min"),
    posNem = rank(-nem, ties.method="min"),
    posRanking = rank(-ranking, ties.method="min"),
) %>%
select(`rbd`, `codEdu`, `nombre`, `matemática1`, `matemática2`, `lectura`,
       `ciencias`, `historia`, `nem`, `ranking`, `promedio`, `dep`, `nse`,
       `posPromedio`, `posMatemática1`, `posMatemática2`, `posLectura`,
       `posCiencias`, `posHistoria`, `posNem`, `posRanking`,
       `región`, `comuna`) -> datos

################# GUARDADO DE LOS DATOS

write_delim(datos, 'datos_paes_2024.csv', delim="|")
openxlsx::write.xlsx(datos, 'datos_paes_2024.xlsx')
datos %>% jsonlite::toJSON(pretty=TRUE) %>% write('datos_paes_2024.json')

#################  GRAFICAS Y OTROS CALCULOS

## FILTRAR LOS DATOS PARA EVALUAR SOLO LOS CIENTIFICO-HUMANISTAS

filter(datos, codEdu == 310) -> datos

### GRAFICO DE CAJA POR TIPO DE DEPENDENCIA

datos %>%
group_by(dep) %>%
summarise(boxplot= list( setNames(boxplot.stats(`matemática1`)$stats,c('low','q1','q2','q3','upper') ) ) ) %>%
unnest_wider(boxplot)

# RESULTADO
# A tibble: 3 × 6
#  dep         low    q1    q2    q3 upper
#  <fct>     <dbl> <dbl> <dbl> <dbl> <dbl>
#1 Público    461.  527.  548.  575.  646.
#2 P. C/Subv  466.  558.  589.  622.  717.
#3 P. S/Subv  509.  663.  739.  803.  942.

datos %>% ggplot(data=.) + geom_boxplot(aes(x=`matemática1`, y=`dep`))

### GRAFICO DE BARRAS CON EL CONTEO DE ESTABLECIMIENTOS

datos %>% group_by(dep,nse) %>% summarize(n())

# A tibble: 11 × 3
# Groups:   dep [3]
#   dep       nse        `n()`
#   <fct>     <fct>      <int>
# 1 Público   Bajo         239
# 2 Público   Medio Bajo   233
# 3 Público   Medio        112
# 4 Público   Medio Alto    12
# 5 P. C/Subv Bajo          68
# 6 P. C/Subv Medio Bajo   391
# 7 P. C/Subv Medio        556
# 8 P. C/Subv Medio Alto   300
# 9 P. C/Subv Alto          14
#10 P. S/Subv Medio Alto    34
#11 P. S/Subv Alto         397

datos %>% ggplot() + geom_bar(aes(x=`dep`,fill=`nse`),position = "dodge2")

## GRAFICO DE CAJA POR TIPO DE DEPENDENCIA Y NIVEL SOCIOECONOMICO

datos %>%
group_by(dep,nse) %>%
summarise(boxplot= list( setNames(boxplot.stats(`matemática1`)$stats,c('low','q1','q2','q3','upper') ) ) ) %>%
unnest_wider(boxplot)

## RESULTADO
# A tibble: 11 × 7
# Groups:   dep [3]
#   dep       nse          low    q1    q2    q3 upper
#   <fct>     <fct>      <dbl> <dbl> <dbl> <dbl> <dbl>
# 1 Público   Bajo        473.  517.  537.  560.  623.
# 2 Público   Medio Bajo  471   529.  547.  569   628.
# 3 Público   Medio       495.  550.  580.  620.  718 
# 4 Público   Medio Alto  607.  624.  682.  736.  855.
# 5 P. C/Subv Bajo        454.  522.  544.  570.  638.
# 6 P. C/Subv Medio Bajo  469.  537.  563.  589.  666.
# 7 P. C/Subv Medio       491.  565.  592.  616.  690.
# 8 P. C/Subv Medio Alto  524.  601.  633.  661.  747.
# 9 P. C/Subv Alto        636.  649.  701.  719.  758 
#10 P. S/Subv Medio Alto  518   586.  622.  671.  722.
#11 P. S/Subv Alto        509.  674.  750.  807.  942.

datos %>% ggplot() + geom_boxplot(aes(x=`dep`,y=`matemática1`,fill=`nse`))

## NEM, RANKING Y MATEMÁTICA M1 POR CATEGORIA DE DESEMPEÑO
datos %>% 
    group_by(dep) %>%
    mutate(posiciones = case_when(
        `matemática1` >= quantile(`matemática1`,0.95, type=1, names=FALSE) ~ "5% Mejor",
        `matemática1` >= quantile(`matemática1`,0.90, type=1, names=FALSE) ~ "10% Mejor",
        `matemática1` >= quantile(`matemática1`,0.80, type=1, names=FALSE) ~ "20% Mejor",
        `matemática1` >= quantile(`matemática1`,0.70, type=1, names=FALSE) ~ "30% Mejor",
        `matemática1` >= quantile(`matemática1`,0.60, type=1, names=FALSE) ~ "40% Mejor",
        `matemática1` >= quantile(`matemática1`,0.50, type=1, names=FALSE) ~ "50% Mejor",
        .default = "50% Peor")) %>% 
    ungroup() %>%
    bind_rows(.,mutate(datos,posiciones="Todos")) %>%
    mutate(posiciones = factor(posiciones, levels=c("Todos", "50% Peor", "50% Mejor", "40% Mejor",
    "30% Mejor", "20% Mejor", "10% Mejor", "5% Mejor"))) %>%
    pivot_longer(cols=c(`matemática1`,nem,ranking), names_to="evaluaciones", values_to="puntajes") %>%
    mutate(evaluaciones = factor(evaluaciones, levels=c("nem", "ranking","matemática1"))) %>%
    group_by(posiciones,evaluaciones,dep) %>%
    summarise(media=mean(puntajes),n=n()) %>%
    print(n=Inf)

# A tibble: 72 × 5
# Groups:   posiciones, evaluaciones [24]
#   posiciones evaluaciones dep       media     n
#   <fct>      <fct>        <fct>     <dbl> <int>
# 1 Todos      nem          Público    704.   596
# 2 Todos      nem          P. C/Subv  724.  1329
# 3 Todos      nem          P. S/Subv  807.   431
# 4 Todos      ranking      Público    724.   596
# 5 Todos      ranking      P. C/Subv  743.  1329
# 6 Todos      ranking      P. S/Subv  821.   431
# 7 Todos      matemática1  Público    557.   596
# 8 Todos      matemática1  P. C/Subv  594.  1329
# 9 Todos      matemática1  P. S/Subv  733.   431
#10 50% Peor   nem          Público    683.   297
#11 50% Peor   nem          P. C/Subv  702.   664
#12 50% Peor   nem          P. S/Subv  779.   215
#13 50% Peor   ranking      Público    706.   297
#14 50% Peor   ranking      P. C/Subv  723.   664
#15 50% Peor   ranking      P. S/Subv  797.   215
#16 50% Peor   matemática1  Público    523.   297
#17 50% Peor   matemática1  P. C/Subv  554.   664
#18 50% Peor   matemática1  P. S/Subv  654.   215
#19 50% Mejor  nem          Público    705.    60
#20 50% Mejor  nem          P. C/Subv  732.   133
#21 50% Mejor  nem          P. S/Subv  818.    43
#22 50% Mejor  ranking      Público    722.    60
#23 50% Mejor  ranking      P. C/Subv  749.   133
#24 50% Mejor  ranking      P. S/Subv  830.    43
#25 50% Mejor  matemática1  Público    553.    60
#26 50% Mejor  matemática1  P. C/Subv  596.   133
#27 50% Mejor  matemática1  P. S/Subv  752.    43
#28 40% Mejor  nem          Público    717.    60
#29 40% Mejor  nem          P. C/Subv  731.   133
#30 40% Mejor  nem          P. S/Subv  827.    43
#31 40% Mejor  ranking      Público    734.    60
#32 40% Mejor  ranking      P. C/Subv  748.   133
#33 40% Mejor  ranking      P. S/Subv  835.    43
#34 40% Mejor  matemática1  Público    563.    60
#35 40% Mejor  matemática1  P. C/Subv  608.   133
#36 40% Mejor  matemática1  P. S/Subv  777.    43
#37 30% Mejor  nem          Público    719.    59
#38 30% Mejor  nem          P. C/Subv  738.   133
#39 30% Mejor  nem          P. S/Subv  839.    43
#40 30% Mejor  ranking      Público    738.    59
#41 30% Mejor  ranking      P. C/Subv  755.   133
#42 30% Mejor  ranking      P. S/Subv  847.    43
#43 30% Mejor  matemática1  Público    575.    59
#44 30% Mejor  matemática1  P. C/Subv  622.   133
#45 30% Mejor  matemática1  P. S/Subv  804.    43
#46 20% Mejor  nem          Público    732.    59
#47 20% Mejor  nem          P. C/Subv  751.   133
#48 20% Mejor  nem          P. S/Subv  841.    43
#49 20% Mejor  ranking      Público    748.    59
#50 20% Mejor  ranking      P. C/Subv  769.   133
#51 20% Mejor  ranking      P. S/Subv  849.    43
#52 20% Mejor  matemática1  Público    594.    59
#53 20% Mejor  matemática1  P. C/Subv  645.   133
#54 20% Mejor  matemática1  P. S/Subv  837.    43
#55 10% Mejor  nem          Público    745.    31
#56 10% Mejor  nem          P. C/Subv  770.    66
#57 10% Mejor  nem          P. S/Subv  851.    22
#58 10% Mejor  ranking      Público    762.    31
#59 10% Mejor  ranking      P. C/Subv  786.    66
#60 10% Mejor  ranking      P. S/Subv  860.    22
#61 10% Mejor  matemática1  Público    621.    31
#62 10% Mejor  matemática1  P. C/Subv  675.    66
#63 10% Mejor  matemática1  P. S/Subv  869.    22
#64 5% Mejor   nem          Público    761.    30
#65 5% Mejor   nem          P. C/Subv  781.    67
#66 5% Mejor   nem          P. S/Subv  853.    22
#67 5% Mejor   ranking      Público    773.    30
#68 5% Mejor   ranking      P. C/Subv  795.    67
#69 5% Mejor   ranking      P. S/Subv  861.    22
#70 5% Mejor   matemática1  Público    709.    30
#71 5% Mejor   matemática1  P. C/Subv  718.    67
#72 5% Mejor   matemática1  P. S/Subv  900.    22

### DIFERENCIA DE PUBLICOS Y SUBVENCIONADOS CON P. S/SUBV POR CATEGORIA DE DESEMPEÑO

datos %>% 
    group_by(dep) %>%
    mutate(posiciones = case_when(
        `matemática1` >= quantile(`matemática1`,0.95, type=1, names=FALSE) ~ "5% Mejor",
        `matemática1` >= quantile(`matemática1`,0.90, type=1, names=FALSE) ~ "10% Mejor",
        `matemática1` >= quantile(`matemática1`,0.80, type=1, names=FALSE) ~ "20% Mejor",
        `matemática1` >= quantile(`matemática1`,0.70, type=1, names=FALSE) ~ "30% Mejor",
        `matemática1` >= quantile(`matemática1`,0.60, type=1, names=FALSE) ~ "40% Mejor",
        `matemática1` >= quantile(`matemática1`,0.50, type=1, names=FALSE) ~ "50% Mejor",
        .default = "50% Peor")) %>% 
    ungroup() %>%
    bind_rows(.,mutate(datos,posiciones="Todos")) %>%
    mutate(posiciones = factor(posiciones, levels=c("Todos", "50% Peor", "50% Mejor", "40% Mejor",
    "30% Mejor", "20% Mejor", "10% Mejor", "5% Mejor"))) %>%
    pivot_longer(cols=c(`matemática1`,nem,ranking), names_to="evaluaciones", values_to="puntajes") %>%
    mutate(evaluaciones = factor(evaluaciones, levels=c("nem", "ranking","matemática1"))) %>%
    group_by(posiciones,evaluaciones) %>%
    mutate(media_pp = mean(puntajes[dep=="P. S/Subv"])) %>%
    ungroup() %>%
    group_by(posiciones,evaluaciones,dep) %>%
    summarise(dif_pp = max(media_pp)-mean(puntajes)) %>%
    filter(dep!="P. S/Subv") %>%
    print(n=Inf)

## A tibble: 48 × 4
## Groups:   posiciones, evaluaciones [24]
#   posiciones evaluaciones dep       dif_pp
#   <fct>      <fct>        <fct>      <dbl>
# 1 Todos      nem          Público    103. 
# 2 Todos      nem          P. C/Subv   83.2
# 3 Todos      ranking      Público     96.7
# 4 Todos      ranking      P. C/Subv   78.0
# 5 Todos      matemática1  Público    176. 
# 6 Todos      matemática1  P. C/Subv  139. 
# 7 50% Peor   nem          Público     95.9
# 8 50% Peor   nem          P. C/Subv   76.4
# 9 50% Peor   ranking      Público     90.8
#10 50% Peor   ranking      P. C/Subv   73.7
#11 50% Peor   matemática1  Público    130. 
#12 50% Peor   matemática1  P. C/Subv   99.8
#13 50% Mejor  nem          Público    114. 
#14 50% Mejor  nem          P. C/Subv   86.6
#15 50% Mejor  ranking      Público    108. 
#16 50% Mejor  ranking      P. C/Subv   80.5
#17 50% Mejor  matemática1  Público    200. 
#18 50% Mejor  matemática1  P. C/Subv  157. 
#19 40% Mejor  nem          Público    110. 
#20 40% Mejor  nem          P. C/Subv   95.4
#21 40% Mejor  ranking      Público    101. 
#22 40% Mejor  ranking      P. C/Subv   87.4
#23 40% Mejor  matemática1  Público    214. 
#24 40% Mejor  matemática1  P. C/Subv  169. 
#25 30% Mejor  nem          Público    119. 
#26 30% Mejor  nem          P. C/Subv  100. 
#27 30% Mejor  ranking      Público    110. 
#28 30% Mejor  ranking      P. C/Subv   92.0
#29 30% Mejor  matemática1  Público    229. 
#30 30% Mejor  matemática1  P. C/Subv  182. 
#31 20% Mejor  nem          Público    109. 
#32 20% Mejor  nem          P. C/Subv   90.1
#33 20% Mejor  ranking      Público    101. 
#34 20% Mejor  ranking      P. C/Subv   80.0
#35 20% Mejor  matemática1  Público    243. 
#36 20% Mejor  matemática1  P. C/Subv  192. 
#37 10% Mejor  nem          Público    106. 
#38 10% Mejor  nem          P. C/Subv   80.9
#39 10% Mejor  ranking      Público     98.0
#40 10% Mejor  ranking      P. C/Subv   74.3
#41 10% Mejor  matemática1  Público    248. 
#42 10% Mejor  matemática1  P. C/Subv  195. 
#43 5% Mejor   nem          Público     91.2
#44 5% Mejor   nem          P. C/Subv   71.7
#45 5% Mejor   ranking      Público     88.6
#46 5% Mejor   ranking      P. C/Subv   65.9
#47 5% Mejor   matemática1  Público    191. 
#48 5% Mejor   matemática1  P. C/Subv  182. 


#### GRAFICA DIFERENCIA ENTRE PP Y PUBLICO  POR CATEGORIA DE DESEMPEÑO
datos %>% 
    group_by(dep) %>%
    mutate(posiciones = case_when(
        `matemática1` >= quantile(`matemática1`,0.95, type=1, names=FALSE) ~ "5% Mejor",
        `matemática1` >= quantile(`matemática1`,0.90, type=1, names=FALSE) ~ "10% Mejor",
        `matemática1` >= quantile(`matemática1`,0.80, type=1, names=FALSE) ~ "20% Mejor",
        `matemática1` >= quantile(`matemática1`,0.70, type=1, names=FALSE) ~ "30% Mejor",
        `matemática1` >= quantile(`matemática1`,0.60, type=1, names=FALSE) ~ "40% Mejor",
        `matemática1` >= quantile(`matemática1`,0.50, type=1, names=FALSE) ~ "50% Mejor",
        .default = "50% Peor")) %>% 
    ungroup() %>%
    bind_rows(.,mutate(datos,posiciones="Todos")) %>%
    mutate(posiciones = factor(posiciones, levels=c("Todos", "50% Peor", "50% Mejor", "40% Mejor",
    "30% Mejor", "20% Mejor", "10% Mejor", "5% Mejor"))) %>%
    pivot_longer(cols=c(`matemática1`,nem,ranking), names_to="evaluaciones", values_to="puntajes") %>%
    mutate(evaluaciones = factor(evaluaciones, levels=c("nem", "ranking","matemática1"))) %>%
    group_by(posiciones,evaluaciones,dep) %>%
    mutate(media=mean(puntajes),n=n()) %>%
    ungroup() %>%
    group_by(posiciones,evaluaciones) %>%
    mutate(media_max = max(media)) %>%
    group_by(posiciones,evaluaciones,dep) %>%
    summarise(diferencia=max(media_max)-max(media)) %>%
    filter(dep=="Público") %>%
    ggplot(data=.) + geom_col(aes(x=diferencia,y=evaluaciones,fill=evaluaciones)) + facet_grid(rows=vars(posiciones)) +
    scale_x_continuous(expand =  expansion(mult = c(0, .1))) +
    theme(axis.title.y=element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank(), legend.position="top")

#### GRAFICA DIFERENCIA  P. S/SUBV. Y P. C/SUBV. POR CATEGORIA DE DESEMPEÑO

datos %>% 
    group_by(dep) %>%
    mutate(posiciones = case_when(
        `matemática1` >= quantile(`matemática1`,0.95, type=1, names=FALSE) ~ "5% Mejor",
        `matemática1` >= quantile(`matemática1`,0.90, type=1, names=FALSE) ~ "10% Mejor",
        `matemática1` >= quantile(`matemática1`,0.80, type=1, names=FALSE) ~ "20% Mejor",
        `matemática1` >= quantile(`matemática1`,0.70, type=1, names=FALSE) ~ "30% Mejor",
        `matemática1` >= quantile(`matemática1`,0.60, type=1, names=FALSE) ~ "40% Mejor",
        `matemática1` >= quantile(`matemática1`,0.50, type=1, names=FALSE) ~ "50% Mejor",
        .default = "50% Peor")) %>% 
    ungroup() %>%
    bind_rows(.,mutate(datos,posiciones="Todos")) %>%
    mutate(posiciones = factor(posiciones, levels=c("Todos", "50% Peor", "50% Mejor", "40% Mejor",
    "30% Mejor", "20% Mejor", "10% Mejor", "5% Mejor"))) %>%
    pivot_longer(cols=c(`matemática1`,nem,ranking), names_to="evaluaciones", values_to="puntajes") %>%
    mutate(evaluaciones = factor(evaluaciones, levels=c("nem", "ranking","matemática1"))) %>%
    group_by(posiciones,evaluaciones,dep) %>%
    mutate(media=mean(puntajes),n=n()) %>%
    ungroup() %>%
    group_by(posiciones,evaluaciones) %>%
    mutate(media_max = max(media)) %>%
    group_by(posiciones,evaluaciones,dep) %>%
    summarise(diferencia=max(media_max)-max(media)) %>%
    filter(dep=="P. C/Subv") %>%
    ggplot(data=.) + geom_col(aes(x=diferencia,y=evaluaciones,fill=evaluaciones)) + facet_grid(rows=vars(posiciones)) +
    scale_x_continuous(expand =  expansion(mult = c(0, .1))) +
    theme(axis.title.y=element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank(), legend.position="top")


## GRAFICA DE PUNTO: NEM VS RANKING
datos %>% ggplot(data=.) + geom_point(aes(x=nem,y=ranking),alpha=0.2)



datos %>%
group_by(dep) %>% 
mutate(
    q10 = quantile(`matemática1`,type=1,names = FALSE),
    q90=quantile(`matemática1`,type=1,names = FALSE)) %>%
filter(`matemática1`>q10 & `matemática1`<q90) %>%
summarise(mean(`matemática1`),sd(`matemática1`))
